import React from 'react';
import './App.css';
import { Body } from './components/Body/Body';

const App = props => {
  return (
    <>
      <Body/>
    </>
  );
}

export default App;

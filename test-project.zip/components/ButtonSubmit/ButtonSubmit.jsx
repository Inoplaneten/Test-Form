import React from 'react';
import './ButtonSubmit.scss';

const ButtonSubmit = () => <button type="submit" className="btnSubmit">Submit</button>

export {ButtonSubmit};